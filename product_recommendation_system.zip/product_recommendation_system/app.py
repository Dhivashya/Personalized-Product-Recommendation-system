import streamlit as st
import pandas as pd
import numpy as np
from surprise import Dataset, Reader, SVDpp
from surprise.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# ------------------------
# Load Datasets
# ------------------------
@st.cache_data
def load_data():
    # Load review data
    reviews_df = pd.read_csv("sample_amazon_reviews.csv")
    reviews_df["user_id"] = reviews_df["user_id"].astype(str)
    reviews_df["product_id"] = reviews_df["product_id"].astype(str)
    reviews_df["product_title"] = reviews_df["product_title"].fillna("Unknown Product")
    reviews_df["image_url"] = reviews_df.get("image_url", pd.Series([""] * len(reviews_df))).fillna("")
    reviews_df["category"] = reviews_df.get("category", pd.Series(["Uncategorized"] * len(reviews_df))).fillna("Uncategorized")

    # Load product catalog data
    products_df = pd.read_csv("sample_dataset.csv")
    products_df["Product ID"] = products_df["Product ID"].astype(str)
    products_df["Product Name"] = products_df["Product Name"].fillna("Unknown Product")
    products_df["Image URL"] = products_df.get("Image URL", pd.Series([""] * len(products_df))).fillna("")
    products_df["Category"] = products_df.get("Category", pd.Series(["Uncategorized"] * len(products_df))).fillna("Uncategorized")

    # Standardize column names (replace spaces with underscores)
    products_df.columns = products_df.columns.str.replace(' ', '_')

    return reviews_df, products_df

# ------------------------
# Train Collaborative Filtering Model
# ------------------------
@st.cache_resource
def train_model(data):
    reader = Reader(rating_scale=(1, 5))
    surprise_data = Dataset.load_from_df(data[["user_id", "product_id", "rating"]], reader)
    trainset, _ = train_test_split(surprise_data, test_size=0.2, random_state=42)
    model = SVDpp()
    model.fit(trainset)
    return model, trainset

# ------------------------
# Content-Based Filtering
# ------------------------
@st.cache_data
def build_content_model(data):
    data['combined_features'] = data['product_title'] + ' ' + data['category']
    tfidf = TfidfVectorizer(stop_words="english")
    tfidf_matrix = tfidf.fit_transform(data['combined_features'])
    return tfidf, cosine_similarity(tfidf_matrix)

def get_content_recommendations(user_id, data, similarity_matrix, top_n=5):
    user_data = data[data["user_id"] == user_id]
    if user_data.empty:
        return pd.DataFrame()
    last_product = user_data.iloc[-1]["product_id"]
    try:
        product_index = data[data["product_id"] == last_product].index[0]
    except IndexError:
        return pd.DataFrame()
    sim_scores = sorted(enumerate(similarity_matrix[product_index]), key=lambda x: x[1], reverse=True)
    recommended_indices = [i for i, _ in sim_scores[1:top_n+1]]
    return data.iloc[recommended_indices].drop_duplicates("product_id")

# ------------------------
# Collaborative Filtering Recommendations
# ------------------------
def get_collaborative_recommendations(user_id, model, trainset, data, top_n=5):
    try:
        inner_uid = trainset.to_inner_uid(user_id)
        rated = {trainset.to_raw_iid(iid) for iid, _ in trainset.ur[inner_uid]}
    except ValueError:
        return pd.DataFrame()

    predictions = []
    for iid in trainset.all_items():
        raw_iid = trainset.to_raw_iid(iid)
        if raw_iid not in rated:
            pred = model.predict(user_id, raw_iid)
            predictions.append((raw_iid, pred.est))

    top_recs = sorted(predictions, key=lambda x: x[1], reverse=True)[:top_n]
    top_ids = [x[0] for x in top_recs]
    return data[data["product_id"].isin(top_ids)].drop_duplicates("product_id")

# ------------------------
# Hybrid Recommendations
# ------------------------
def get_hybrid_recommendations(user_id, model, trainset, data, similarity_matrix, top_n=5):
    collab = get_collaborative_recommendations(user_id, model, trainset, data, top_n=10)
    content = get_content_recommendations(user_id, data, similarity_matrix, top_n=10)
    combined = pd.concat([collab, content]).drop_duplicates("product_id")
    return combined.head(top_n)

# ------------------------
# Get Similar Products from Catalog
# ------------------------
def get_similar_products_from_catalog(product_title, category, products_df, tfidf, top_n=5):
    # Add the current product to the catalog temporarily
    temp_df = products_df.copy()
    temp_df.loc[-1] = {
        'Product_ID': 'temp',
        'Product_Name': product_title,
        'Category': category,
        'Price_(USD)': 0,
        'Image_URL': ''
    }

    # Create combined features
    temp_df['combined_features'] = temp_df['Product_Name'] + ' ' + temp_df['Category']

    # Transform using existing TF-IDF
    tfidf_matrix = tfidf.transform(temp_df['combined_features'])
    similarity_matrix = cosine_similarity(tfidf_matrix)

    # Get similarity scores for our temp product
    product_index = len(temp_df) - 1
    sim_scores = list(enumerate(similarity_matrix[product_index]))

    # Sort and get top matches (excluding itself)
    sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)[1:top_n+1]
    similar_indices = [i for i, _ in sim_scores]

    return temp_df.iloc[similar_indices]

# ------------------------
# Display Recommendations
# ------------------------
def display_recommendations(recs, reviews_df, products_df, tfidf):
    if recs.empty:
        st.warning("No recommendations found. Try a different user or method.")
        return

    if 'expanded_products' not in st.session_state:
        st.session_state.expanded_products = {}

    for _, row in recs.iterrows():
        product_id = row["product_id"]
        with st.container():
            cols = st.columns([1, 4])
            with cols[0]:
                img = row["image_url"].strip() or "https://via.placeholder.com/100"
                st.image(img, width=100)
                if st.button("View Similar Products", key=f"btn_{product_id}"):
                    st.session_state.expanded_products[product_id] = not st.session_state.expanded_products.get(product_id, False)
                    st.rerun()
            with cols[1]:
                st.markdown(f"**{row['product_title']}**")
                st.markdown(f"*Category*: {row['category']}")
                st.markdown(f"*Price*: ${row['price']:.2f}")
                st.markdown(f"*Rating*: {row['rating']:.1f} / 5.0")

        # Show similar items from catalog if expanded
        if st.session_state.expanded_products.get(product_id, False):
            similar_products = get_similar_products_from_catalog(
                row['product_title'],
                row['category'],
                products_df,
                tfidf,
                top_n=5
            )
            
            if not similar_products.empty:
                st.markdown("#### Similar Products from Catalog")
                for _, srow in similar_products.iterrows():
                    scols = st.columns([1, 4])
                    with scols[0]:
                        sim_img = srow["Image_URL"].strip() or "https://via.placeholder.com/80"
                        st.image(sim_img, width=80)
                    with scols[1]:
                        st.markdown(f"**{srow['Product_Name']}**")
                        st.markdown(f"*Category*: {srow['Category']}")
                        st.markdown(f"*Price*: ${srow['Price_(USD)']:.2f}")
                st.markdown("---")
            else:
                st.warning("No similar products found in catalog.")

# ------------------------
# Main App
# ------------------------
def main():
    st.set_page_config(page_title="🛒 Product Recommendation System", layout="wide")
    st.title("🛍️ Personalized Product Recommendation System")

    if 'expanded_products' not in st.session_state:
        st.session_state.expanded_products = {}

    reviews_df, products_df = load_data()
    model, trainset = train_model(reviews_df)
    tfidf, similarity_matrix = build_content_model(reviews_df)

    st.sidebar.header("User Controls")
    user_ids = sorted(reviews_df["user_id"].unique())
    selected_user = st.sidebar.selectbox("Select User ID", user_ids)

    if 'method' not in st.session_state:
        st.session_state.method = "Collaborative"

    def on_method_change():
        st.session_state.method = st.session_state.recommendation_method
        st.session_state.expanded_products = {}

    st.sidebar.radio("Recommendation Type", 
                     ["Collaborative", "Content-Based", "Hybrid"], 
                     key="recommendation_method", 
                     on_change=on_method_change)

    st.subheader(f"Recommendations for User **{selected_user}** using *{st.session_state.method} Filtering*")

    if st.session_state.method == "Collaborative":
        recs = get_collaborative_recommendations(selected_user, model, trainset, reviews_df)
    elif st.session_state.method == "Content-Based":
        recs = get_content_recommendations(selected_user, reviews_df, similarity_matrix)
    else:
        recs = get_hybrid_recommendations(selected_user, model, trainset, reviews_df, similarity_matrix)

    display_recommendations(recs, reviews_df, products_df, tfidf)

if __name__ == "__main__":
    main()